import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './auth.guard';
import { LoginComponent } from './layout/login/login.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { Dashboard2Component } from './pages/dashboard2/dashboard2.component';
import { TopComponent } from './layout/top/top.component';
import { MainComponent } from './layout/main/main.component';
import { ReviewskillsComponent } from './pages/masters/reviewskills/reviewskills.component';
import { BulkquestionsComponent } from './pages/masters/bulkquestions/bulkquestions.component';
import { BulkuserComponent } from './pages/masters/bulkuser/bulkuser.component';
import { DomainComponent } from './pages/masters/domain/domain.component';
import { ExpertlevelComponent } from './pages/masters/expertlevel/expertlevel.component';
import { OrganizationComponent } from './pages/masters/organization/organization.component';
import { UsergroupsComponent } from './pages/masters/usergroups/usergroups.component';
import { QuestionsComponent } from './pages/masters/questions/questions.component';
import { ExpertreviewComponent } from './pages/expert/expertreview/expertreview.component';
import { ExpertviewComponent } from './pages/expert/expertview/expertview.component';
import { GeneratecouponsComponent } from './pages/payments/generatecoupons/generatecoupons.component';
import { PaymentmanagementComponent } from './pages/payments/paymentmanagement/paymentmanagement.component';
import { UserinterviewComponent } from './pages/payments/userinterview/userinterview.component';
import { InterviewtypesComponent } from './pages/masters/interviewtypes/interviewtypes.component';
import { UserprofileComponent } from './pages/usermanagement/userprofile/userprofile.component';
import { UserdomainmapComponent } from './pages/usermanagement/userdomainmap/userdomainmap.component';
import { PaypalComponent } from './pages/payments/paypal/paypal.component';
import { ChequemanagementComponent } from './pages/payments/chequemanagement/chequemanagement.component';
import { ForgetpasswordComponent } from '../app/layout/forgetpassword/forgetpassword.component';
import { CreateinterviewComponent } from '../app/pages/payments/createinterview/createinterview.component';
import { ProcessinterviewComponent } from '../app/pages/payments/processinterview/processinterview.component';
import { CrowdbulkquestionsComponent } from './pages/masters/crowdbulkquestions/crowdbulkquestions.component';
import { CrowdquestionsComponent } from './pages/masters/crowdquestions/crowdquestions.component';
import { QualitycheckComponent } from './pages/masters/qualitycheck/qualitycheck.component';

import { ResetpasswordComponent } from '../app/layout/resetpassword/resetpassword.component';
import { ExamComponent } from './layout/exam/exam.component';
import { EntrypageComponent } from './layout/exam/entrypage/entrypage.component';
import { InstructionsComponent } from './layout/exam/instructions/instructions.component';
import { MockComponent } from './layout/exam/mock/mock.component';
import { FinishComponent } from './layout/exam/finish/finish.component';
import { DisplayExamsComponent } from './layout/exam/display-exams/display-exams.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TestmysetupComponent } from './layout/exam/testmysetup/testmysetup.component';
import { VideosComponent } from './layout/exam/videos/videos.component';
import { SpeechComponent } from './layout/exam/speech/speech.component';
import { AssignexpertComponent } from './pages/expert/assignexpert/assignexpert.component';
import { ReviewComponent } from './layout/exam/review/review.component';

import { ConfirmationGuard } from './layout/exam/confirmation/confirmation.guard';
import { Exam2Component } from './layout/exam/exam2/exam2.component';
import { Entrypage2Component } from './layout/exam/entrypage2/entrypage2.component';
import { Testmysetup2Component } from './layout/exam/testmysetup2/testmysetup2.component';
import { Dialog1Component } from './layout/exam/dialog1/dialog1.component';
import { Mock2Component } from './layout/exam/mock2/mock2.component';
import { Videos2Component } from './layout/exam/videos2/videos2.component';
import { ListinterviewsComponent } from './layout/exam/listinterviews/listinterviews.component';
import { Userprofile2Component } from './layout/exam/userprofile2/userprofile2.component';
import { Instructions2Component } from './layout/exam/instructions2/instructions2.component';
import { ReviewsComponent } from './layout/exam/reviews/reviews.component';

// const routes: Routes = [
//   { path: 'login', component: LoginComponent },
//   { path: 'home', component: MainDashboardComponent, canActivate: [AuthGuard]  },
//   { path: 'cdm', component: CreateCdmComponent, canActivate: [AuthGuard] },
//   { path: 'user', component: CreateUserComponent, canActivate: [AuthGuard]  },
//   { path: 'error', component: ErrorComponent },
//   { path: 'change-password', component: ChangePasswordComponent, canActivate: [AuthGuard]  },
//   {
//     path: '',
//     redirectTo: 'login',
//     pathMatch: 'full'
//   },
//   {
//     path: '**',
//     component: ErrorNotFoundComponent
// }
// ];

const routes: Routes = [
	{ path: '', redirectTo: 'login', pathMatch: 'full' },
	{ path: 'login', component: LoginComponent },
	{ path: "forget-password", component: ForgetpasswordComponent },

	{
		path: 'main',
		component: MainComponent,
		children: [
			{ path: 'main', component: MainComponent, outlet: 'main' },
			{ path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] },
			{ path: 'dashboard2', component: Dashboard2Component, canActivate: [AuthGuard] },
			{ path: 'reviewskills', component: ReviewskillsComponent, canActivate: [AuthGuard] },
			{ path: 'bulkquestions', component: BulkquestionsComponent, canActivate: [AuthGuard] },
			{ path: 'bulkuser', component: BulkuserComponent, canActivate: [AuthGuard] },
			{ path: 'domain', component: DomainComponent, canActivate: [AuthGuard] },
			{ path: 'expertlevel', component: ExpertlevelComponent, canActivate: [AuthGuard] },
			{ path: 'organization', component: OrganizationComponent, canActivate: [AuthGuard] },
			{ path: 'usergroup', component: UsergroupsComponent, canActivate: [AuthGuard] },
			{ path: 'interviewtype', component: InterviewtypesComponent, canActivate: [AuthGuard] },
			{ path: 'userprofile', component: UserprofileComponent, canActivate: [AuthGuard] },
			{ path: 'userdomainmap', component: UserdomainmapComponent, canActivate: [AuthGuard] },
			{ path: 'expertreview', component: ExpertreviewComponent, canActivate: [AuthGuard] },
			{ path: "expertview", component: ExpertviewComponent, canActivate: [AuthGuard] },
			{ path: "generate-coupon", component: GeneratecouponsComponent, canActivate: [AuthGuard] },
			{ path: "paymentmgmt", component: PaymentmanagementComponent, canActivate: [AuthGuard] },
			{ path: "userinterview", component: UserinterviewComponent, canActivate: [AuthGuard] },
			{ path: "chequemgmt", component: ChequemanagementComponent, canActivate: [AuthGuard] },
			{ path: "questions", component: QuestionsComponent, canActivate: [AuthGuard] },
			{ path: 'crowdbulkquestions', component: CrowdbulkquestionsComponent, canActivate: [AuthGuard] },
			{ path: "crowdquestions", component: CrowdquestionsComponent, canActivate: [AuthGuard] },
			{ path: "qualitycheck", component: QualitycheckComponent, canActivate: [AuthGuard] },
			{ path: 'dashboard', component: DashboardComponent },
			{ path: 'dashboard2', component: Dashboard2Component },
			{ path: 'reviewskills', component: ReviewskillsComponent },
			{ path: 'bulkquestions', component: BulkquestionsComponent },
			{ path: 'bulkuser', component: BulkuserComponent },
			{ path: 'domain', component: DomainComponent },
			{ path: 'expertlevel', component: ExpertlevelComponent },
			{ path: 'organization', component: OrganizationComponent },
			{ path: 'usergroup', component: UsergroupsComponent },
			{ path: 'interviewtype', component: InterviewtypesComponent },
			{ path: 'userprofile', component: UserprofileComponent },
			{ path: 'userdomainmap', component: UserdomainmapComponent },
			{ path: 'expertreview', component: ExpertreviewComponent },
			{ path: "expertview", component: ExpertviewComponent },
			{ path: "generate-coupon", component: GeneratecouponsComponent },
			{ path: "userinterview", component: UserinterviewComponent },
			{ path: "chequemgmt", component: ChequemanagementComponent },
			{ path: "questions", component: QuestionsComponent },
			{ path: "payment", component: PaypalComponent },
			{ path: "forget-password", component: ForgetpasswordComponent },
			{ path: "create-interview", component: CreateinterviewComponent },
			{ path: "process-interview", component: ProcessinterviewComponent },
			{ path: "assign-interview", component: AssignexpertComponent },
			{ path: "change-password", component: ResetpasswordComponent },
			{ path: '', redirectTo: 'dashboard', pathMatch: 'full' }

		]
	},
	{
		path: 'examboard2', component: Exam2Component,
		children: [
			{ path: 'examboard2', component: Exam2Component, outlet: 'exam2' },
			{ path: 'entrypage2', component: Entrypage2Component },
			{ path: 'userprofile2', component: Userprofile2Component },
			{ path: 'testsetup2', component: Testmysetup2Component },
			{ path: 'viewvideos2', component: Videos2Component },
			{ path: 'listinterviews2', component: ListinterviewsComponent },
			{ path: 'instructions2', component: Instructions2Component },
			{ path: 'reviews', component: ReviewsComponent }



		]
	},

	{
		path: 'examboard', component: ExamComponent,
		children: [
			{ path: 'examboard', component: ExamComponent, outlet: 'exam' },
			{ path: 'entrypage', component: EntrypageComponent },
			{ path: 'instructions', component: InstructionsComponent },
			{ path: 'mock', component: MockComponent, canDeactivate: [ConfirmationGuard] },
			{ path: 'viewreviews', component: FinishComponent },
			{ path: 'interviews', component: DisplayExamsComponent },
			{ path: 'testsetup', component: TestmysetupComponent },
			{ path: 'videos', component: VideosComponent },
			{ path: 'speech', component: SpeechComponent },
			{ path: 'change-password', component: ResetpasswordComponent },
			{ path: 'paymentmgmt', component: PaymentmanagementComponent },
			{ path: 'userprofile', component: UserprofileComponent },
			{ path: 'reviews', component: ReviewComponent },


		]
	},

	{
		path: 'mocktest', component: Mock2Component,
		children: [
			{ path: 'mocktest', component: Mock2Component, outlet: 'mocks' },
			{ path: 'mocktest2', component: Mock2Component, canDeactivate: [ConfirmationGuard] },

		]
	},
	{
		path: '**',
		redirectTo: '/login'
	}
];

@NgModule({
	imports: [RouterModule.forRoot(routes)],
	exports: [RouterModule]
})
export class AppRoutingModule { }
