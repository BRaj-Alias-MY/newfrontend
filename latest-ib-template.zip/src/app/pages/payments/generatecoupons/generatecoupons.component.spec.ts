import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GeneratecouponsComponent } from './generatecoupons.component';

describe('GeneratecouponsComponent', () => {
  let component: GeneratecouponsComponent;
  let fixture: ComponentFixture<GeneratecouponsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GeneratecouponsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GeneratecouponsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
