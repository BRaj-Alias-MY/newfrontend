import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { FileUploader, FileSelectDirective } from 'ng2-file-upload/ng2-file-upload';
import { NgSelectModule } from '@ng-select/ng-select';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NgDatepickerModule } from 'ng2-datepicker';
import { Ng2GoogleChartsModule } from 'ng2-google-charts';
import { AgGridModule } from 'ag-grid-angular';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ApiService } from './services/api.service';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { JwtInterceptor } from './jwt.interceptor';
import { ChartsModule } from 'ng2-charts/ng2-charts';
import { Ng5SliderModule } from 'ng5-slider';
import {
	MatButtonModule,
	MatGridListModule,
	MatCardModule,
	MatInputModule,
	MatCheckboxModule,
	MatIconModule,
	MatSidenavModule,
	MatMenuModule,
	MatToolbarModule,
	MatExpansionModule,
	MatTabsModule,
	MatSelectModule
} from '@angular/material';
import { MainComponent } from './layout/main/main.component';
import { AuthGuard } from './auth.guard';
import { ChildMessageRenderer } from './childmessagerender.component';
import { LoginComponent } from './layout/login/login.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { Dashboard2Component } from './pages/dashboard2/dashboard2.component';
import { TopComponent } from './layout/top/top.component';
import { ReviewskillsComponent } from './pages/masters/reviewskills/reviewskills.component';
import { BulkquestionsComponent } from './pages/masters/bulkquestions/bulkquestions.component';
import { BulkuserComponent } from './pages/masters/bulkuser/bulkuser.component';
import { DomainComponent } from './pages/masters/domain/domain.component';
import { ExpertlevelComponent } from './pages/masters/expertlevel/expertlevel.component';
import { QuestionsComponent } from './pages/masters/questions/questions.component';
import { OrganizationComponent } from './pages/masters/organization/organization.component';
import { IntquestiontemplatesComponent } from './pages/masters/intquestiontemplates/intquestiontemplates.component';
import { UsergroupsComponent } from './pages/masters/usergroups/usergroups.component';
import { InterviewtypesComponent } from './pages/masters/interviewtypes/interviewtypes.component';
import { UserprofileComponent } from './pages/usermanagement/userprofile/userprofile.component';
import { UserdomainmapComponent } from './pages/usermanagement/userdomainmap/userdomainmap.component';
import { ForgetpasswordComponent } from './layout/forgetpassword/forgetpassword.component';
import { ResetpasswordComponent } from './layout/resetpassword/resetpassword.component';
import { PaypalComponent } from './pages/payments/paypal/paypal.component';
import { NgxPayPalModule } from 'ngx-paypal';
import { GeneratecouponsComponent } from './pages/payments/generatecoupons/generatecoupons.component';
import { PaymentmanagementComponent } from './pages/payments/paymentmanagement/paymentmanagement.component';
import { UserinterviewComponent } from './pages/payments/userinterview/userinterview.component';
import { ExpertviewComponent } from './pages/expert/expertview/expertview.component';
import { ExpertreviewComponent } from './pages/expert/expertreview/expertreview.component';
import { ChequemanagementComponent } from './pages/payments/chequemanagement/chequemanagement.component';
import { CreateinterviewComponent } from './pages/payments/createinterview/createinterview.component';
import { ProcessinterviewComponent } from './pages/payments/processinterview/processinterview.component';

import { ExamComponent } from './layout/exam/exam.component';
import { EntrypageComponent } from './layout/exam/entrypage/entrypage.component';
import { InstructionsComponent } from './layout/exam/instructions/instructions.component';
import { MockComponent } from './layout/exam/mock/mock.component';
import { FinishComponent } from './layout/exam/finish/finish.component';
import { DisplayExamsComponent } from './layout/exam/display-exams/display-exams.component';
import { TestmysetupComponent } from './layout/exam/testmysetup/testmysetup.component';
import { VideosComponent } from './layout/exam/videos/videos.component';
import { SpeechComponent } from './layout/exam/speech/speech.component';
import { AssignexpertComponent } from './pages/expert/assignexpert/assignexpert.component';
import { AdminDashboardComponent } from './pages/dashboards/admin-dashboard/admin-dashboard.component';
import { ExpertDashboardComponent } from './pages/dashboards/expert-dashboard/expert-dashboard.component';
import { UserDashboardComponent } from './pages/dashboards/user-dashboard/user-dashboard.component';
import { OrginationDashboardComponent } from './pages/dashboards/orgination-dashboard/orgination-dashboard.component';
import { ReviewComponent } from './layout/exam/review/review.component';
import { CrowdquestionsComponent } from './pages/masters/crowdquestions/crowdquestions.component';
import { CrowdbulkquestionsComponent } from './pages/masters/crowdbulkquestions/crowdbulkquestions.component';
import { QualitycheckComponent } from './pages/masters/qualitycheck/qualitycheck.component';

import { ConfirmationGuard } from './layout/exam/confirmation/confirmation.guard';
import { CameraComponent } from './layout/exam/camera/camera.component';
import { Exam2Component } from './layout/exam/exam2/exam2.component';
import { Entrypage2Component } from './layout/exam/entrypage2/entrypage2.component';
import { Testmysetup2Component } from './layout/exam/testmysetup2/testmysetup2.component';
import { Dialog1Component } from './layout/exam/dialog1/dialog1.component';
import { Mock2Component } from './layout/exam/mock2/mock2.component';
import { MatDialogModule } from '@angular/material/dialog';
import { Videos2Component } from './layout/exam/videos2/videos2.component';
import { ListinterviewsComponent } from './layout/exam/listinterviews/listinterviews.component';
import { Userprofile2Component } from './layout/exam/userprofile2/userprofile2.component';

@NgModule({
	declarations: [
		AppComponent,
		MainComponent,
		LoginComponent,
		DashboardComponent,
		FileSelectDirective,
		Dashboard2Component,
		TopComponent,
		ReviewComponent,
		ChildMessageRenderer,
		ReviewskillsComponent,
		BulkquestionsComponent,
		DomainComponent,
		ExpertlevelComponent,
		BulkuserComponent,
		QuestionsComponent,
		OrganizationComponent,
		IntquestiontemplatesComponent,
		UsergroupsComponent,
		InterviewtypesComponent,
		UserprofileComponent,
		UserdomainmapComponent,
		ForgetpasswordComponent,
		ResetpasswordComponent,
		PaypalComponent,
		GeneratecouponsComponent,
		PaymentmanagementComponent,
		UserinterviewComponent,
		ExpertviewComponent,
		ExpertreviewComponent,
		ChequemanagementComponent,
		CreateinterviewComponent,
		ProcessinterviewComponent,
		ExamComponent,
		EntrypageComponent,
		InstructionsComponent,
		MockComponent,
		FinishComponent,
		DisplayExamsComponent,
		TestmysetupComponent,
		VideosComponent,
		SpeechComponent,
		AssignexpertComponent,
		AdminDashboardComponent,
		ExpertDashboardComponent,
		UserDashboardComponent,
		OrginationDashboardComponent,
		CrowdquestionsComponent,
		CrowdbulkquestionsComponent,
		QualitycheckComponent,
		CameraComponent,
		Exam2Component,
		Entrypage2Component,
		Testmysetup2Component,
		Mock2Component,
		Dialog1Component,
		Videos2Component,
		ListinterviewsComponent,
		Userprofile2Component,


	],
	imports: [
		Ng5SliderModule,
		MatDialogModule,
		BrowserModule,
		BrowserAnimationsModule,
		AppRoutingModule,
		MatIconModule,
		MatGridListModule,
		MatMenuModule,
		MatCardModule,
		BrowserAnimationsModule,
		MatSidenavModule,
		MatExpansionModule,
		MatButtonModule,
		MatCheckboxModule,
		MatInputModule,
		MatToolbarModule,
		MatSelectModule,
		MatTabsModule,
		NgSelectModule,
		NgxSpinnerModule,
		HttpClientModule,
		NgDatepickerModule,
		Ng2GoogleChartsModule,
		FormsModule,
		ReactiveFormsModule,
		NgxPayPalModule,
		ChartsModule,
		AgGridModule.withComponents([ChildMessageRenderer])
	],
	schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
	providers: [ConfirmationGuard, ApiService, { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true }, AuthGuard],
	bootstrap: [AppComponent],
	entryComponents: [Dialog1Component]
})
export class AppModule { }
