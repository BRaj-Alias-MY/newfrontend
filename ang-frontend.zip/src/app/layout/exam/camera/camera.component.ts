import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AppService } from "../../../app.service";
declare var $: any;
declare const CameraTag: any;
@Component({
  selector: 'app-camera',
  templateUrl: './camera.component.html',
  styleUrls: ['./camera.component.css']
})
export class CameraComponent implements OnInit {

  @Input() questionTime: any;
  @Output() public childEvent = new EventEmitter();
  constructor(private service: AppService) { }

  ngOnInit() {

    this.fireEvent();

  }
  fireEvent() {

    this.childEvent.emit(this.questionTime);

  }




}
