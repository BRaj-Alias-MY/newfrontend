import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userprofile2',
  templateUrl: './userprofile2.component.html',
  styleUrls: ['./userprofile2.component.css']
})
export class Userprofile2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
